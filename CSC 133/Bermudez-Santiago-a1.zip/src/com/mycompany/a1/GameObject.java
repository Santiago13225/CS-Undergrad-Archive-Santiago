package com.mycompany.a1;

import java.util.Random;
import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;

/**
 * A class that is used primarily by the GameWorld class. This is an abstract class that gets extended by other classes to help
 * bring the game world some life. It is extended by the Fixed and Movable classes. This class represents a basic game object 
 * and features some attributes and methods that are sure to be referred to by its children. Functions include:
 * Setting and getting x and y values, setting and getting size, setting and getting color, and the toString method. 
 * 
 * @author Santiago A. Bermudez
 * @version 1 September 2022
 */
public abstract class GameObject {
	
	private static final int WORLDWIDTH = 1000;
	private static final int WORLDHEIGHT = 1000;
	
	private int size;
	//private Point location = new Point();
	private Point location;
	//private double xVal;
	//private double yVal;
	private int color;
	private Random random = new Random();
/**
 * This method instantiates a game object.
 */	
	public GameObject() {
		
	}
/**
 * This method instantiates a game object with a manual location setting.
 *
 * @param size retrieves the soon to be size of an object.
 * @param location retrieves the soon to be location of an object.
 * @param red retrieves the soon to be red color value of an object.
 * @param green retrieves the soon to be green color value of an object.
 * @param blue retrieves the soon to be blue color value of an object.
 */
	public GameObject(int size, Point location, int red, int green, int blue) {
		if (size < 10) {
            throw new IllegalArgumentException("Size must be at least 10!");
        }
		this.size = size;
		this.location = location;
		this.color = ColorUtil.rgb(red, green, blue);
	}
/**
 * This method instantiates a game object and randomly sets its location.
 * 
 * @param size retrieves the soon to be size of an object.
 * @param red retrieves the soon to be red color value of an object.
 * @param green retrieves the soon to be green color value of an object.
 * @param blue retrieves the soon to be blue color value of an object.
 */
	public GameObject(int size, int red, int green, int blue) {
		if (size < 10) {
            throw new IllegalArgumentException("Size must be at least 10!");
        }		
		this.size = size;
		//this.xVal = (double)random.nextInt(1000);//nextInt(int) returns a random integer from the entire range of integers.
		//this.yVal = (double)random.nextInt(1000);//It also returns a random number between zero (inclusive) and the specified integer parameter (exclusive).
		this.setLocation(new Point(random.nextInt(1000), random.nextInt(1000)));
		
		this.color = ColorUtil.rgb(red, green, blue);
	}
/**
 * Gets the current location of the object.
 *
 * @return the Point location of the object in question.
 */
	public Point getLocation() {
		return this.location;
	}	
/**
 * Sets the current location of the object.
 *
 * @param point retrieves the coordinates for the location.
 */	
	public void setLocation(Point point) {
		this.location = point;
	}
/**
 * This method sets the size of an object.
 *
 * @param newSize retrieves the size to set an object to.
 */	
	public void setSize(int newSize) {
		this.size = newSize;
	}
/**
 * Returns the current size of the object.
 *
 * @return the integer size of the object in question.
 */
	public int getSize() {
		return size;
	}	
/**
 * Returns the current red color value of the object.
 *
 * @return the ColorUtil red value in an integer.
 */	
	public int getRedVal() {
		return ColorUtil.red(color);
	}
/**
 * Returns the current green color value of the object.
 *
 * @return the ColorUtil green value in an integer.
 */	
	public int getGreenVal() {
		return ColorUtil.green(color);
	}
/**
 * Returns the current blue color value of the object.
 *
 * @return the ColorUtil blue value in an integer.
 */	
	public int getBlueVal() {
		return ColorUtil.blue(color);
	}
/**
 * This method sets the color of an object with the the RGB values used together.
 * 
 * @param red retrieves the soon to be red color value of an object.
 * @param green retrieves the soon to be green color value of an object.
 * @param blue retrieves the soon to be blue color value of an object.
 */
	public void setColor(int red, int green, int blue) {
		color = ColorUtil.rgb(red, green, blue);
	}
/**
 * Returns a string description of the object.
 *
 * @return the size, location, and color of the object in string format.
 */
	public String toString() {
        return "Size: " + size + " Location: " + this.getLocation().getX() + ", " + this.getLocation().getY() + " Color: " + "[" + ColorUtil.red(color) + "," + ColorUtil.green(color) + "," + ColorUtil.blue(color) + "]"; 
    }

}
