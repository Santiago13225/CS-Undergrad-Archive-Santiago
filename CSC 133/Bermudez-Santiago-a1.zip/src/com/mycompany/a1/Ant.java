package com.mycompany.a1;

import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;

/**
 * A class that extends the Movable class and implements the ISteerable interface. This is an Ant class that gets controlled 
 * by the player. It uses the ISteerable interface for manual turning of the ant by the player. Functions include:
 * instantiating an ant, setting and getting the last flag that the ant has reached, setting and getting food levels
 * , setting and getting health levels, setting and getting maximum speed, turning, accelerating, decelerating, and 
 * a toString method.
 * 
 * @author Santiago A. Bermudez
 * @version 1 September 2022
 */
public class Ant extends Movable implements ISteerable {

	private int maximumSpeed;
	private int foodLevel;
	private int foodConsumptionRate;
	private int healthLevel;
	private int lastFlagReached;
	private Point location = new Point();
/**
 * This method instantiates an ant, setting color, speed, direction, maximum speed, food levels, 
 * health levels, the last flag reached, size, position, and so on.
 */
	public Ant() {
		super.setColor(205, 0, 0);
		super.initSpeed(5);
		super.setDirection(0);
		this.maximumSpeed = 50;
		this.foodLevel = 100;
		this.foodConsumptionRate = 1;
		this.healthLevel = 10;
		this.lastFlagReached = 1;
		super.setSize(20);
		//super.setXVal(10);
		//super.setYVal(10);
		super.setLocation(new Point(10, 10));
	}
/**
 * Sets the last flag reached by an ant in sequential order.
 *
 * @param flagNum retrieves the number of the flag that is being registered for evaluation.
 * @return the integer value of the the last flag reached in sequential order.
 */
	public int setLastFlag(int flagNum) {
		if(flagNum < 0) {
			System.out.println("Sorry! There are no negative flags!");
		} else if (flagNum >= 10) {
			System.out.println("Sorry! There are no flags above 10!");
		} else if (flagNum < this.lastFlagReached) {
			System.out.println("Sorry! You can\'t go backwards! You have to reach the next flag!");
		} else if (flagNum >= this.lastFlagReached + 2) {
			System.out.println("Sorry! You can\'t skip ahead, you have to reach all the flags in order!");
		} else {
			this.lastFlagReached = flagNum;
		}
		return lastFlagReached;
	}
/**
 * Gets the last flag reached by an ant in sequential order.
 *
 * @return the integer value of the last flag reached in sequential order.
 */
	public int getLastFlag() {
		return lastFlagReached;
	}
/**
 * Gets the food consumption rate of an ant.
 *
 * @return the integer value of how much food the ant is eating per unit of time.
 */
	public int getFoodConsumption() {
		return foodConsumptionRate;
	}
/**
 * Sets the food level of an ant.
 *
 * @param foodL retrieves the amount of food to set for the ant.
 * @return the integer value of how much food the ant has left.
 */
	public int setFood(int foodL) {
		this.foodLevel = foodL;
		return getFood();
	}
/**
 * Sets the health level of an ant.
 *
 * @param healthL retrieves the amount of health to set for the ant.
 * @return the integer value of how much health the ant has left.
 */
	public int setHealth(int healthL) {
		this.healthLevel = healthL;
		return getHealth();
	}
/**
 * Gets the food level of an ant.
 *
 * @return the integer value of how much food the ant still has left.
 */
	public int getFood() {
		return foodLevel;
	}
/**
 * Sets the maximum speed of an ant based on its health.
 *
 * @return the toString method showing the ant's new maximum speed.
 */
	public String setMaxSpeed() {
		this.maximumSpeed = getHealth() * 5;
		if(super.getSpeed() > this.maximumSpeed) {
			super.initSpeed(this.maximumSpeed);
		}
		return toString();
	}
/**
 * Gets the maximum speed of an ant.
 *
 * @return the ant's maximum speed.
 */
	public int getMaxSpeed() {
		return maximumSpeed;
	}
/**
 * Reduces the food level of an ant.
 *
 * @param foodLevel retrieves the amount of food the ant has to subtract from.
 * @return the integer value of how much food the ant has left.
 */
	public int reduceFoodLevel(int foodLevel) {
		int newF = this.foodLevel - this.foodConsumptionRate;
		return setFood(newF);
	}
/**
 * Gets the current health value of an ant.
 *
 * @return the integer value of how much health the ant has left.
 */
	public int getHealth() {
		return healthLevel;
	}
/**
 * Reduces the health level of an ant.
 *
 * @param healthLevel retrieves the amount of health the ant has to subtract from.
 * @return the integer value of how much health the ant has after taking damage.
 */	
	public int reduceHealthLevel(int healthLevel) {
		int newH = this.healthLevel - 1;
		return setHealth(newH);
	}
/**
 * Method used to manually turn the ant left by 5 degrees.
 */	
	public void turnLeft() {
		super.setDirection(super.getDirection() - 5);
		System.out.println("The ant has turned left 5 degrees!");
	}
/**
 * Method used to manually turn the ant right by 5 degrees.
 */	
	public void turnRight() {
		super.setDirection(super.getDirection() + 5);
		System.out.println("The ant has turned right 5 degrees!");
	}
/**
 * Returns a string description of the ant.
 *
 * @return a message in string showing the ant's details.
 */
	public String toString() {
		return "Ant: loc = " + super.getLocation().getX() + ", " + super.getLocation().getY() + " color = [" + super.getRedVal() + ", " + super.getGreenVal() + ", "
				+ super.getBlueVal() + "]" + " heading = " + super.getDirection() + " speed = " + super.getSpeed() + " size = " + super.getSize() 
				+ " max speed = " + getMaxSpeed() + " food consumption rate = " + getFoodConsumption() + " health = " + getHealth() 
				+ " food level = " + getFood();
	}
/**
 * Method used to manually accelerate the ant (*with limitations based on health).
 */	
	public void incSpeed() {
		if(super.getSpeed() == maximumSpeed) {
			System.out.println("The ant is already at maximum speed, it can't go any faster!");
		} else if (foodLevel == 0) {
			System.out.println("The ant has starved to death (*Food level = 0), it won't be able to move any more!");
		} else if (healthLevel == 0) {
			System.out.println("The ant has died (*Health level = 0), it won't be able to move any more!");
		} else {
			maximumSpeed = getHealth() * 5;
			super.initSpeed(super.getSpeed() + 5);
			System.out.println("The ant has accelerated!");
			//super.initSpeed(super.getSpeed() + (2 * getHealth()));//????????????????????????????????????????????????????
		}
		
	}
/**
 * Method used to manually decelerate the ant.
 */		
	public void decSpeed() {
		if(super.getSpeed() > 0) {
			maximumSpeed = getHealth() * 5;
			super.initSpeed(super.getSpeed() - 5);
			System.out.println("The ant has decelerated!");
		} else if (super.getSpeed() <= 0) {
			super.initSpeed(0);
			System.out.println("The ant is already stopped (*Speed = 0), it can't slow down any further!");
		} else {
			System.out.println("Something went wrong while trying to decrease the speed!");
		}
	}

}
