package com.mycompany.a1;

import com.codename1.charts.models.Point;

/**
 * A class that extends the GameObject class. This is an abstract class that focuses on and handles fixed
 * objects. It is extended by the Flag and FoodStation classes. This class represents the basic features of a fixed 
 * object and features some attributes and methods that involve objects that should not move at all. There are empty 
 * body implementations just to ensure that some methods don't get used on a fixed object. 
 * 
 * @author Santiago A. Bermudez
 * @version 1 September 2022
 */
public abstract class Fixed extends GameObject{
	
	//private Point location = new Point();
/**
 * This method instantiates a fixed object.
 */
	public Fixed() {
		
	}
/**
 * This method instantiates a fixed object with a manual color setting.
 *
 * @param red retrieves the soon to be red color value of an object.
 * @param green retrieves the soon to be green color value of an object.
 * @param blue retrieves the soon to be blue color value of an object.
 */
	public Fixed(int red, int green, int blue) {
		super.setColor(red, green, blue);
	}
/**
 * This is an empty body implementation to prevent an attempt to move
 * a fixed object.
 */
	public void move() {
		System.out.println("Error: Fixed GameObject cannot be moved.");
	}
/*
	public void setLocation() {
		System.out.println("Error: Fixed GameObject cannot have its location be set.");
	}
	
	public void setLocation(Point point) {
		System.out.println("Error: Fixed GameObject cannot have its location be set.");
	}
*/
/**
 * Returns a string description of the fixed object.
 *
 * @return a message if it is just a fixed object that is not concrete.
 */
	public String toString() {
		return "This is just a Fixed object, there is nothing to see here.";
	}
	
}
