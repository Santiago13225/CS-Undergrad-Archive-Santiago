package com.mycompany.a1;

import com.codename1.charts.models.Point;

/**
 * A class that extends the GameObject class. This is an abstract class that focuses on and handles movable
 * objects. It is extended by the Ant and Spider classes. This class represents the basic features of a movable 
 * object and features some attributes and methods that involve objects that can move. Functions include:
 * Moving an object based on its speed and heading, setting and getting an object's direction, setting and
 * getting an object's speed, and the toString method.
 * 
 * @author Santiago A. Bermudez
 * @version 1 September 2022
 */
public abstract class Movable extends GameObject {
	
	private int heading;
	private int speed;
/**
 * This method instantiates a movable object.
 */
	public Movable() {
		
	}
/**
 * This method instantiates a movable object with a manual location setting.
 *
 * @param location retrieves the soon to be position of an object.
 * @param red retrieves the soon to be red color value of an object.
 * @param green retrieves the soon to be green color value of an object.
 * @param blue retrieves the soon to be blue color value of an object.
	 */
	public Movable(Point location, int red, int green, int blue) {
		super.setLocation(location);
		super.setColor(red, green, blue);		
	}
/**
 * This method instantiates a game object without a manual location setting.
 * 
 * @param red retrieves the soon to be red color value of an object.
 * @param green retrieves the soon to be green color value of an object.
 * @param blue retrieves the soon to be blue color value of an object.
 */
	public Movable(int red, int green, int blue) {
		super.setColor(red, green, blue);		
	}
/**
 * This method moves a game object from its current location based on 
 * its current heading and speed.
 */
	public void move(){
		//double curXPos = super.getXVal();
		//double curYPos = super.getYVal();
		double x = this.getLocation().getX();
		double y = this.getLocation().getY();
		double theta = Math.toRadians(90 - heading);
		double dX = Math.round(Math.cos(theta) * 10.0 * speed) / 10.0;
		double dY = Math.round(Math.sin(theta) * 10.0 * speed) / 10.0;
		double newX = Math.round((x + dX) * 10.0) / 10.0;
		double newY = Math.round((y + dY) * 10.0) / 10.0;
		//super.setXVal(newX);
		//super.setYVal(newY);
		super.setLocation(new Point((float)newX, (float)newY));
	}
/**
 * This method sets a game object's heaing.
 * 
 * @param theta retrieves the angle of degrees for an object.
 */
	public void setDirection(int theta) {
		if (theta >= 0 && theta < 360) {
			heading = theta;
		} else if (theta < 0) {
			heading = theta % 360 + 360;
		} else {
			heading = theta % 360;
		}
	}
/**
 * Returns the current heading of an object.
 *
 * @return the integer in degrees of the angle of an object.
 */
	public int getDirection() {
		return heading;
	}
/**
 * This method sets a game object's speed.
 * 
 * @param spd retrieves the speed set on an object.
 */
	public void initSpeed(int spd) {
		if(spd < 0) {
			speed = 0;
		} else if (spd > 50) {
			speed = 50;
		} else {
			speed = spd;
		}
	}
/**
 * Returns the current speed of an object.
 *
 * @return the integer in speed of an object.
 */
	public int getSpeed() {
		return speed;
	}
/**
 * Returns a string description of the movable object.
 *
 * @return a message if it is just a movable object that is not concrete.
 */
	public String toString() {
		return "This is just a Movable object, there is nothing to see here.";
	}
	
}
