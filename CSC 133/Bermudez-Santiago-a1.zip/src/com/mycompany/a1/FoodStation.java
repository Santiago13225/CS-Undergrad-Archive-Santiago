package com.mycompany.a1;

import java.util.Random;

import com.codename1.charts.models.Point;

/**
 * A class that extends the Fixed class. This is a FoodStation class that does not move at all and serves as an aid 
 *  for the player. Functions include: instantiating an a food station, clearing the food station of its food
 *  capacity, getting the food station's capacity, and a toString method.
 * 
 * @author Santiago A. Bermudez
 * @version 1 September 2022
 */
public class FoodStation extends Fixed {

	//private int size;
	private int capacity;
	private Point location = new Point();
	private Random random = new Random();
/**
 * This method instantiates a food station, setting color, capacity, size, and position.
 */
	public FoodStation() {
		super.setColor(0, 255, 0);
		//this.size = random.nextInt(41) + 10;
		super.setSize(random.nextInt(41) + 10);
		super.setLocation(new Point(random.nextInt(1000), random.nextInt(1000)));
		capacity = super.getSize();
	}
/**
 * This method will empty a food station and change its color to light green when an ant
 * comes by to eat all of the food within it.
 */
	public void emptyFStation() {
		super.setColor(127, 255, 148);
		capacity = 0;
	}
/**
 * Gets the food capacity of a food station.
 *
 * @return the integer value of food capacity.
 */
	public int getCapacity() {
		return capacity;
	}
	
	/*
	public int getSize() {
		return this.size;
	}*/
/**
 * Returns a string description of the food station.
 *
 * @return a message in string showing the food station's details.
 */
	public String toString() {
		return "FoodStation: loc = " + super.getLocation().getX() + ", " + super.getLocation().getY() + " color = [" + super.getRedVal() + ", " + super.getGreenVal() + ", "
				+ super.getBlueVal() + "]" + " size = " + super.getSize() + " capacity = " + getCapacity();
	}
}
