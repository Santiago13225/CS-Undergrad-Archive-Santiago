package com.mycompany.a1;

import java.util.Observable;
import java.util.Random;

import com.codename1.charts.models.Point;

import java.util.ArrayList;

/**
 * A class that is used primarily by the Game class. This GameWorld class holds a collection of game objects and other state 
 * variables. It features methods to handle the many game commands that will be executed by the player like: accelerating the 
 * ant, decelerating the ant, steering the ant left and right, pretending that the ant has walked over a certain flag, 
 * pretending that the ant has walked over a food station, pretending that the ant was bitten by a spider, advancing the time
 * in the game world, displaying game states, showing a 'map' of the world, and exiting the game.
 * 
 * @author Santiago A. Bermudez
 * @version 1 September 2022
 */
public class GameWorld extends Observable{
//public class GameWorld {
	
	//private int worldWidth = 1000;
	//private int worldHeight = 1000;		
	private int lives = 3;
	private int time = 0;
	private Ant player;
	private int antCounter = 0;
	private int lastFlagReached = 0;
	//private Point location;
	private int addSub = 1;
	private int flagCount = 0;
	//private int numberOfItemsToChoose = 1;
	public Random random = new Random();
	
	private ArrayList<Object> list;
/**
 * This method instantiates a game world with an array list of objects.
 */
	public GameWorld() {
		this.list = new ArrayList<Object>();// Creating arraylist
	}	
/**
 * This method initiates the first world by using methods to create objects and
 * adding them to the array list.
 */
	public void init() {
		/*Code here to create the initial game objects/setup*/		
		addFlag1();
		addFlag2();
		addFlag3();
		addFlag4();
		addAnt();
		for(int i = 0; i < random.nextInt(2) + 2; i++) {
			addSpider();
		}
		addFoodStation();
		addFoodStation();
		addFoodStation();
		updateWorld();
	}
/**
 * This method handles the loss of a life by re-initiating the world by using methods 
 * to clear objects from the array list and by adding new ones. It also resets the 
 * player's ant back to its initial state.
 */
	public void reInitWorld() {
		//int element = 0;
		/*Code here to create the initial game objects/setup*/
		//while(this.list.size() != 0) {
		//for (String fruit : this.list()) {
		for (int element = this.list.size() - 1; element >= 0; element--) {
			/*
			if (this.list.get(element) instanceof Ant) {
				//list.remove(element);
				resetAnt();
				
				//list.add(player);
				continue;
			}*/
			if (this.list.get(element) instanceof Spider) {
				list.remove(element);
			} else if (this.list.get(element) instanceof FoodStation) {
				list.remove(element);
			}
			/*
			if (this.list.get(element) instanceof GameObject) {
				list.remove(element);
			}*/
		}
		/*
		addFlag1();
		addFlag2();
		addFlag3();
		addFlag4();
		*/
		resetAnt();
		for(int i = 0; i < random.nextInt(2) + 2; i++) {
			addSpider();
		}
		addFoodStation();
		addFoodStation();
		addFoodStation();
		updateWorld();
	}
/**
 * This method handles the quit command that is entered by the player. It tries to 
 * confirm the player's decision to leave the game via a prompt. 
 */
	public void exit() {
		System.out.println("Are you sure you want to quit? Press 'y' to confirm. Press 'n' to cancel.");
	}
/**
 * This method handles exiting the game. If the player has confirmed that they want
 * to quit, then we call System.exit(0) to terminate the program.
 */
	public void exitConfirmed() {
		System.out.println();
		System.out.println("Player has left the game.");
		System.exit(0);
	}
/**
 * This method handles updating the world.???????????????????????????????????????????????????????????????????
 */
	public void updateWorld() {
		System.out.println("Updated world!");
		setChanged();
	}
/**
 * This method handles acceleration of the ant.
 */
	public void accelerate() {
			player.incSpeed();
			System.out.println(player.toString());
			System.out.println();
	}
/**
 * This method handles deceleration of the ant.
 */
	public void brake() {
			player.decSpeed();
			System.out.println(player.toString());
			System.out.println();
	}
/**
 * This method checks to see if the player has won the game by reaching the last flag.
 */
	public void checkWin() {
		if(player.getLastFlag() >= flagCount) {
			System.out.println();
			System.out.println("Game over, you win! Total time: " + time);
			System.exit(0);
		}
	}
/**
 * This method will pretend that the player has reached the first flag.
 */
	public void fOne() {
		player.setLastFlag(1);
		System.out.println("Last Flag Reached has been updated!\n");
		checkWin();
	}
/**
 * This method will pretend that the player has reached the second flag.
 */
	public void fTwo() {
		player.setLastFlag(2);
		System.out.println("Last Flag Reached has been updated!\n");
		checkWin();
	}
/**
 * This method will pretend that the player has reached the third flag.
 */
	public void fThree() {
		player.setLastFlag(3);
		System.out.println("Last Flag Reached has been updated!\n");
		checkWin();
	}
/**
 * This method will pretend that the player has reached the fourth flag.
 */
	public void fFour() {
		player.setLastFlag(4);
		System.out.println("Last Flag Reached has been updated!\n");
		checkWin();
	}
/**
 * This method will pretend that the player has reached the fifth flag.
 */
	public void fFive() {
		player.setLastFlag(5);
		System.out.println("Last Flag Reached has been updated!\n");
		checkWin();
	}
/**
 * This method will pretend that the player has reached the sixth flag.
 */
	public void fSix() {
		player.setLastFlag(6);
		System.out.println("Last Flag Reached has been updated!\n");
		checkWin();
	}
/**
 * This method will pretend that the player has reached the seventh flag.
 */
	public void fSeven() {
		player.setLastFlag(7);
		System.out.println("Last Flag Reached has been updated!\n");
		checkWin();
	}
/**
 * This method will pretend that the player has reached the eighth flag.
 */
	public void fEight() {
		player.setLastFlag(8);
		System.out.println("Last Flag Reached has been updated!\n");
		checkWin();
	}
/**
 * This method will pretend that the player has reached the ninth flag.
 */
	public void fNine() {
		player.setLastFlag(9);
		System.out.println("Last Flag Reached has been updated!\n");
		checkWin();
	}
/**
 * This method will pretend that the player has reached a food station, 
 * add to the player's food level and empty the food station.
 */
	public void addFoodStation() {
		FoodStation fStation = new FoodStation();
		this.list.add(fStation);
		System.out.println(fStation.toString());
		updateWorld();
	}	
/**
 * This method will add the first flag. According to the instructions, 
 * all flags should be assigned to locations chosen by the developer, 
 * when they are created. 
 */
	public void addFlag1() {
		//Flag flag = new Flag(10, 10, 1);
		Flag flag = new Flag(new Point(10, 10), 1);
		this.list.add(flag);
		System.out.println(flag.toString());
		flagCount++;
		updateWorld();
	}
/**
 * This method will add the second flag. According to the instructions, 
 * all flags should be assigned to locations chosen by the developer, 
 * when they are created. 
 */
	public void addFlag2() {
		//Flag flag = new Flag(20, 750, 2);
		Flag flag = new Flag(new Point(20, 750), 2);
		this.list.add(flag);
		System.out.println(flag.toString());
		flagCount++;
		updateWorld();
	}
/**
 * This method will add the third flag. According to the instructions, 
 * all flags should be assigned to locations chosen by the developer, 
 * when they are created. 
 */
	public void addFlag3() {
		//Flag flag = new Flag(750, 600, 3);
		Flag flag = new Flag(new Point(750, 600), 3);
		this.list.add(flag);
		System.out.println(flag.toString());
		flagCount++;
		updateWorld();
	}
/**
 * This method will add the fourth flag. According to the instructions, 
 * all flags should be assigned to locations chosen by the developer, 
 * when they are created. 
 */
	public void addFlag4() {
		//Flag flag = new Flag(30, 900, 4);
		Flag flag = new Flag(new Point(30, 900), 4);
		this.list.add(flag);
		System.out.println(flag.toString());
		flagCount++;
		updateWorld();
	}
/**
 * This method will add a spider. All spiders will have random sizes, 
 * random speeds, random locations, random headings, and turn 
 * randomly upon creation.
 */
	public void addSpider() {
		Spider spider = new Spider();
		this.list.add(spider);
		System.out.println(spider.toString());
		updateWorld();
	}
/**
 * This method will add an ant. This object is very special because 
 * the player will be controlling it.
 */	
	public void addAnt() {
		if (antCounter == 0) {
			player = new Ant();
			list.add(player);
			antCounter++;
			System.out.println(player.toString());
			updateWorld();
		} else {
			System.out.println("Error: Ant cannot be created");
		}
	}
/**
 * This method will handle resetting an ant's states. When an ant 
 * has died, the player will have lost a life and the game world 
 * will have re-initialized with the ant back to where it was 
 * at the start of the game.
 */	
	public void resetAnt() {
			player.setHealth(10);
			player.setFood(100);
			player.setMaxSpeed();
			player.initSpeed(5);
			//player.setXVal(10);
			//player.setYVal(10);
			player.setLocation(new Point(10, 10));
			player.setDirection(0);
			player.setColor(205, 0, 0);
			System.out.println("Ant restored!");
			updateWorld();
	}
/**
 * This method will handle manual turning of an ant to the left. 
 */	
	public void turnLeft() {
		player.turnLeft();
		System.out.println(player.toString());
		System.out.println();
	}
/**
 * This method will handle manual turning of an ant to the right. 
 */
	public void turnRight() {
		player.turnRight();
		System.out.println(player.toString());
		System.out.println();
	}
/**
 * This method will display the current game and/or ant state 
 * values. 
 */
	public void display() {
		System.out.println("Lives left: " + getLivesLeft());
		System.out.println("Elapsed Time: " + time);
		System.out.println("Last flag reached: " + player.getLastFlag());
		System.out.println("Food level: " + player.getFood());
		System.out.println("Health level: " + player.getHealth());
		System.out.println();
	}
/**
 * This method will get the health of the ant for use in other 
 * methods.
 * 
 * @return the integer value of the ant's health.
 */
	public int getHealth() {
		if (antCounter == 0) {
			System.out.println("There is no Ant. Not anymore");
			return 0;
		} else {
			return player.getHealth();
		}
	}
/**
 * This method will get the last flag reached for progressing
 * the game.
 * 
 * @return the integer value of the last flag reached.
 */
	public int getLastFlag() {
		if (antCounter == 0) {
			System.out.println("There is no Ant.");
		}
		return player.getLastFlag();
	}
/**
 * This method will get the food level of the player.
 * 
 * @return the integer value of the player's food level.
 */
	public int getFood() {
		return player.getFood();
	}
/**
 * This method will get the time elapsed in the game.
 * 
 * @return the integer value of how much time has 'ticked'.
 */
	public int getTime() {
		return this.time;
	}
/**
 * This method will get the number of lives remaining.
 * 
 * @return the integer value of how many lives the player 
 * has left.
 */
	public int getLivesLeft() {
		return this.lives;
	}	
/**
 * This method will the incrementation of the game clock.
 * Every time the player calls this method, all of the movable
 * objects in the game world will update their own positions 
 * based on heading, location, and speed.
 */
	public void tick() {
		for (int element = 0; element < this.list.size(); element++) {
			if (this.list.get(element) instanceof Spider) {
				Movable move = (Movable) list.get(element);
				
				addSub = (random.nextBoolean() ? 1 : -1);
				//this.heading = getDirection() + (random.nextInt(3) * 5) * addSub;
				//super.setDirection(super.getDirection() + ((random.nextInt(3) * 5) * addSub));
				move.setDirection(move.getDirection() + (5 * addSub));
				move.move();
			}

			if (this.list.get(element) instanceof Ant) {
				Movable move = (Movable) list.get(element);
			
				player.reduceFoodLevel(player.getFood());
				if(player.getFood() == 0) {
					System.out.println("The ant has starved!");
					System.out.println("Life lost!");
					System.out.println();
					lives--;
					reInitWorld();
				}
				if (lives <= 0) {
					System.out.println("");
					System.out.println("Game over, you failed!");
					System.exit(0);
				}
				move.move();
			}
		}
		time++; // incremement the time
		System.out.println("The clock has ticked! Time incremented by 1!");
		System.out.println();
	}
/**
 * This method will pretend that an ant has reached a food station. It 
 * will empty the food station, change its color to light green, feed 
 * the ant by the capacity of the food station, and add another food station.
 */
	public void fStation() {
		System.out.println("Ant has hit a food station!");
		int amountOfFood = 0;
		//for (int element = 0; element < this.list.size(); element++) {
			//if (this.list.get(element) instanceof FoodStation) {
		amountOfFood = emptyFoodStation();
			//} 
			//else {
				//System.out.println("There are no food stations here!");
				//break;
			//}
		
		//int amountOfFood = emptyFoodStation();
		player.setFood(player.getFood() + amountOfFood);
		//emptyFoodStation();
		
		//}
		System.out.println();
	}
/**
 * This method will empty a food station from the array list of 
 * game objects in the game world.
 * 
 * @return the integer value of how much food will be withdrawn 
 * from the food station.
 */
	public int emptyFoodStation() {
		int food = 0;
		for (int element = 0; element < this.list.size(); element++) {
			//random.nextInt(element) + 2
			if (this.list.get(element) instanceof FoodStation) {
				FoodStation fStationTest = (FoodStation) this.list.get(element);
				if (fStationTest.getCapacity() == 0) {
					continue;
				} 
				food = fStationTest.getCapacity();
				fStationTest.emptyFStation();
				//list.remove(element);
				break;
			}
		}
		addFoodStation();
		//FoodStation fStationTest = new FoodStation();
		return food;
	}
/**
 * This method will get a random object from an array list.
 * 
 * @return the random object from the array list.
 */
	public Object getRandomElement(ArrayList<Object> list)
    {
        Random rand = new Random();
        return list.get(rand.nextInt(list.size()));
    }
/**
 * This method will display a map of all the game objects in 
 * the game world.
 */
	public void map() {
		System.out.println("Displaying Map:");
		for (int element = 0; element < this.list.size(); element++) {
			System.out.println(this.list.get(element).toString());
		}
		System.out.println();
	}
/**
 * This method will pretend that a spider has bit the ant. It will 
 * reduce the ant's health, maximum speed, potentially cost a life, 
 * and possibly even cause a game to end if it takes the ant's last 
 * life.
 */
	public void playerHit() // spider hits Ant
	{
		player.reduceHealthLevel(player.getHealth());
		player.setMaxSpeed();
		player.setColor(255 - (5 * player.getHealth()), 0, 0);
		System.out.println("Ouch! Player was hit by a spider!");
		if (player.getHealth() == 0) {
			System.out.println("Life lost!");
			lives--;
			reInitWorld();
		}
		if (lives <= 0) {
			System.out.println("");
			System.out.println("Game over, you failed!");
			System.exit(0);
		}
		System.out.println();
	}
}