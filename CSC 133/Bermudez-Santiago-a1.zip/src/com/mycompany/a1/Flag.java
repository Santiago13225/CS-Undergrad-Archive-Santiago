package com.mycompany.a1;

import com.codename1.charts.models.Point;
//import com.codename1.charts.util.ColorUtil;

/**
 * A class that extends the Fixed class. This is a Flag class that does not move at all and serves as a series of 
 * 'waypoints' for the player. Functions include: instantiating an a flag, getting the flag's sequence number, 
 * and a toString method.
 * 
 * @author Santiago A. Bermudez
 * @version 1 September 2022
 */
public class Flag extends Fixed{
	
	private Point location = new Point();
	//private int size;
	private int sequenceNumber;
	
/**
 * This method instantiates a flag, setting color, sequence number, size, and position.
 */
	public Flag(Point location, int seqNumber) {
		super.setColor(0, 0, 255);
		this.location = location;
		//this.size = 10;
		super.setSize(10);
		this.sequenceNumber = seqNumber;
		super.setLocation(location);
	}
	
/**
 * Gets the sequence number of a flag.
 *
 * @return the integer value of the flag.
 */
	public int getSequenceNumber() {
		return this.sequenceNumber;
	}
	/*
	public int getSize() {
		return this.size;
	}*/
/**
 * This is an empty body implementation to prevent an attempt to set
 * the location of a flag.
 */
	public void setLocation() {
		System.out.println("Error: Flag cannot have its location be set.");
	}
/**
 * This is an empty body implementation to prevent an attempt to set
 * the location of a flag.
 */
	public void setLocation(Point point) {
		System.out.println("Error: Flag cannot have its location be set.");
	}
/**
 * This is an empty body implementation to prevent an attempt to set
 * the color of a flag.
 */
	public void setColor() {
		System.out.println("Error: Flags are not allowed to change color once they are created.");
	}
/**
 * This is an empty body implementation to prevent an attempt to set
 * the color of a flag.
 */
	public void setColor(int red, int green, int blue) {
		System.out.println("Error: Flags are not allowed to change color once they are created.");
	}
/**
 * Returns a string description of the flag.
 *
 * @return a message in string showing the flag's details.
 */
	public String toString() {
		return "Flag: loc = " + super.getLocation().getX() + ", " + super.getLocation().getY() + " color = [" + super.getRedVal() + ", " + super.getGreenVal() + ", "
				+ super.getBlueVal() + "]" + " size = " + super.getSize() + " sequence number = " + getSequenceNumber();
	}
	
}
