package com.mycompany.a1;

import java.util.Random;

import com.codename1.charts.models.Point;

/**
 * A class that extends the Movable class. This is a Spider class that will move on its own randomly without input  
 * from the player. Functions include: instantiating a spider, turning, and a toString method. There is also an empty
 * body implementation to prevent a spider's color from being changed.
 * 
 * @author Santiago A. Bermudez
 * @version 1 September 2022
 */
public class Spider extends Movable {
	
	private int speed;
	public Random random = new Random();
/**
 * This method instantiates an spider, setting color, speed, direction, size, and position.
 */
	public Spider() {
		super.setColor(0, 0, 0);
		super.initSpeed((random.nextInt(6) + 5));
		super.setDirection(random.nextInt(360));
		super.setSize(random.nextInt(41) + 10);
		//super.setXVal(random.nextInt(1000));//Except flags and the ant, initial locations of all the game objects should be assigned randomly when created. 
		//super.setYVal(random.nextInt(1000));
		super.setLocation(new Point(random.nextInt(1000), random.nextInt(1000)));
		if (this.getLocation().getX() <= 0 || this.getLocation().getX() >= 1000 || this.getLocation().getY() <= 0 || this.getLocation().getY() >= 1000) {
			super.setDirection(super.getDirection() + 180);
		}
		super.move();
	}
/**
 * Method used to turn the spider left by 5 degrees.
 */	
	public void turnLeft() { 
		super.setDirection(super.getDirection() - 5);
	}
/**
 * Method used to turn the spider right by 5 degrees.
 */	
	public void turnRight() {
		super.setDirection(super.getDirection() + 5);
	}
	/*
	public int getSpeed( ) {
		return speed;
	}*/
/**
 * Returns a string description of the spider.
 *
 * @return a message in string showing the spider's details.
 */
	public String toString() {
		return "Spider: loc = " + super.getLocation().getX() + ", " + super.getLocation().getY() + " color = [" + super.getRedVal() + ", " + super.getGreenVal() + ", "
				+ super.getBlueVal() + "]" + " heading = " + super.getDirection() + " speed = " + super.getSpeed() + " size = " + super.getSize();
	}
/**
 * This is an empty body implementation to prevent an attempt to 
 * change the spider's color.
 */	
	public void setColor() {
		
	}
}
