package com.mycompany.a1;
import com.codename1.ui.Form;

//More stuff for the play() method:
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;

/**
 * A class that is used primarily by the Starter class. This Game class is where the user will interact with the game through 
 * various commands and prompts. It initiates the game world and lets the player accelerate, decelerate, turn left, turn right, 
 * pretend to hit a flag, pretend to hit a food station, pretend that a spider has bit the player, increment time, display a 
 * 'map', display the game state values, and exit whenever they want.
 * 
 * @author Santiago A. Bermudez
 * @version 1 September 2022
 */
public class Game extends Form{
	private GameWorld gw;
/**
 * This method instantiates a Game with a game world and objects. It also 
 * calls on the play method to let the user play the game.
 */
	public Game() {
		gw = new GameWorld();
		gw.init();
		play();
	}
/**
 * This method handles the various commands that the player needs to 
 * interact with the game and provides feedback as well.
 */
	private void play() {
		//code here to accept and
		//execute user commands that
		//operate on the game world
		//(refer to "Appendix - CN1
		//Notes" for accepting
		//keyboard commands via a text
		//field located on the form)
		
		Label myLabel = new Label("Enter a Command: ");
		this.addComponent(myLabel);
		final TextField myTextField = new TextField();
		this.addComponent(myTextField);
		this.show();
		
		myTextField.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent evt) {
				
				String sCommand = myTextField.getText().toString();
				myTextField.clear();
				if(sCommand.length() != 0)
					switch (sCommand.charAt(0)) {
					case 'a':
						System.out.println("User has entered a!");
						gw.accelerate();
						break;
						//add code to handle rest of the commands
					case 'b':
						System.out.println("User has entered b!");
						gw.brake();
						break;
					case 'l':
						System.out.println("User has entered l!");
						gw.turnLeft();
						//tell the game world to change the heading of the ant by 5 degrees to 
						//the left (in the negative direction on the compass). 
						break;
					case 'r':
						System.out.println("User has entered r!");
						gw.turnRight();
						//tell the game world to change the heading of the ant by 5 degrees to the right (in the 
						//direction on the compass). 
						break;
					case '1':
						System.out.println("User has entered 1!");
						gw.fOne();
						/*� PRETEND that the ant has collided with (walked over) the flag
						number 1 (which must have a value between 1-9); tell the game world that this 
						collision has occurred. The effect of walking over a flag is to check to see whether 
						the number 1 is exactly one greater than the flag indicated by lastFlagReached field 
						of the ant and if so, update the lastFlagReached field of the ant by increasing it by 
						one.*/
						break;
					case '2':
						System.out.println("User has entered 2!");
						gw.fTwo();
						/*� PRETEND that the ant has collided with (walked over) the flag
						number 2 (which must have a value between 1-9); tell the game world that this 
						collision has occurred. The effect of walking over a flag is to check to see whether 
						the number 2 is exactly one greater than the flag indicated by lastFlagReached field 
						of the ant and if so, update the lastFlagReached field of the ant by increasing it by 
						one.*/
						break;
					case '3':
						System.out.println("User has entered 3!");
						gw.fThree();
						/*� PRETEND that the ant has collided with (walked over) the flag
						number 3 (which must have a value between 1-9); tell the game world that this 
						collision has occurred. The effect of walking over a flag is to check to see whether 
						the number 3 is exactly one greater than the flag indicated by lastFlagReached field 
						of the ant and if so, update the lastFlagReached field of the ant by increasing it by 
						one.*/
						break;	
					case '4':
						System.out.println("User has entered 4!");
						gw.fFour();
						/*� PRETEND that the ant has collided with (walked over) the flag
						number 4 (which must have a value between 1-9); tell the game world that this 
						collision has occurred. The effect of walking over a flag is to check to see whether 
						the number 4 is exactly one greater than the flag indicated by lastFlagReached field 
						of the ant and if so, update the lastFlagReached field of the ant by increasing it by 
						one.*/
						break;
					case '5':
						System.out.println("User has entered 5!");
						gw.fFive();
						/*� PRETEND that the ant has collided with (walked over) the flag
						number 5 (which must have a value between 1-9); tell the game world that this 
						collision has occurred. The effect of walking over a flag is to check to see whether 
						the number 5 is exactly one greater than the flag indicated by lastFlagReached field 
						of the ant and if so, update the lastFlagReached field of the ant by increasing it by 
						one.*/
						break;
					case '6':
						System.out.println("User has entered 6!");
						gw.fSix();
						/*� PRETEND that the ant has collided with (walked over) the flag
						number 6 (which must have a value between 1-9); tell the game world that this 
						collision has occurred. The effect of walking over a flag is to check to see whether 
						the number 6 is exactly one greater than the flag indicated by lastFlagReached field 
						of the ant and if so, update the lastFlagReached field of the ant by increasing it by 
						one.*/
						break;	
					case '7':
						System.out.println("User has entered 7!");
						gw.fSeven();
						/*� PRETEND that the ant has collided with (walked over) the flag
						number 7 (which must have a value between 1-9); tell the game world that this 
						collision has occurred. The effect of walking over a flag is to check to see whether 
						the number 7 is exactly one greater than the flag indicated by lastFlagReached field 
						of the ant and if so, update the lastFlagReached field of the ant by increasing it by 
						one.*/
						break;
					case '8':
						System.out.println("User has entered 8!");
						gw.fEight();
						/*� PRETEND that the ant has collided with (walked over) the flag
						number 8 (which must have a value between 1-9); tell the game world that this 
						collision has occurred. The effect of walking over a flag is to check to see whether 
						the number 8 is exactly one greater than the flag indicated by lastFlagReached field 
						of the ant and if so, update the lastFlagReached field of the ant by increasing it by 
						one.*/
						break;
					case '9':
						System.out.println("User has entered 9!");
						gw.fNine();
						/*� PRETEND that the ant has collided with (walked over) the flag
						number 9 (which must have a value between 1-9); tell the game world that this 
						collision has occurred. The effect of walking over a flag is to check to see whether 
						the number 9 is exactly one greater than the flag indicated by lastFlagReached field 
						of the ant and if so, update the lastFlagReached field of the ant by increasing it by 
						one.*/
						break;	
					case 'f':
						System.out.println("User has entered f!");
						gw.fStation();
						/*PRETEND that the ant has collided with a food station; tell the game world that this 
						collision has occurred. The effect of colliding with a food station is to increase the 
						ant�s food level by the capacity of the food station (in this version of the assignment, 
						pick a non-empty food station randomly), reduce the capacity of the food station to 
						zero, fade the color of the food station (e.g., change it to light green), and add a new 
						food station with randomly-specified size and location into the game.*/
						break;	
					case 'g':
						System.out.println("User has entered g!");
						gw.playerHit();
						/*� PRETEND that a spider has gotten to the same location and collided with the ant. 
						The effect of colliding with a spider is to decrease the health level of the ant as 
						described above, fade the color of the ant (i.e., it becomes lighter red � throughout 
						the game, the ant can have different shades of red), and (if necessary) reduce the 
						speed of the ant so that above-mentioned speed-limitation rule is enforced. Since 
						currently no change is introduced to the spider after the collision, it does not matter 
						which spider is picked.*/
						break;	
					case 't':
						System.out.println("User has entered t!");
						gw.tick();
						/*tell the game world that the �game clock� has ticked. A clock tick in the game world 
						has the following effects: (1) Spiders update their heading as indicated above. (2) all 
						movable objects are told to update their positions according to their current heading 
						and speed, and (3) the ant�s food level is reduced by the amount indicated by its 
						foodConsumptionRate, (4) the elapsed time �game clock� is incremented by one (the game clock for this assignment is simply a variable which increments by one with each
						tick). Note that all commands take immediate effect and not depend on �t� command 
						(e.g., if �a� is hit, the ant�s speed value would be increased right away without waiting for 
						the next �t� command to be entered). */
						break;
					case 'd':
						System.out.println("User has entered d!");
						gw.display();
						/*generate a display by outputting lines of text on the console describing the current 
						game/ant state values. The display should include (1) the number of lives left, (2) the 
						current clock value (elapsed time), (3) the highest flag number the ant has reached 
						sequentially so far (i.e., lastFlagReached), (4) the ant�s current food level (i.e., 
						foodLevel), and (5) the ant�s health level (i.e., healthLevel). All output should be 
						appropriately labeled in easily readable format.*/
						break;
					case 'm':
						System.out.println("User has entered m!");
						gw.map();
						/*tell the game world to output a �map� showing the current world.*/
						break;
					case 'x':
						System.out.println("User has entered x!");
						gw.exit();
						/*exit, by calling the method System.exit(0) to terminate the program. Your program 
						should confirm the user�s intent to quit before actually exiting. This means your 
						program should force the user to enter �y� or �n� (see �y� and �n� commands below) to the 
						text field (and hit enter) after (s)he enters �x� to the text field (and hits enter). To 
						accomplish this, consider setting a flag in your code whenever the last entered 
						command from the text field is 'x'. Then, if the last entered command is 'x' and the user 
						does not say �y� or �n� after saying �x�, you can print a message to the console asking for 
						one of these commands and do not accept any other commands*/

						final TextField myTextField2 = new TextField();//Prompts the user for confirmation to exit.
						addComponent(myTextField2);
						removeComponent(myTextField);
						show();
						myTextField2.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent evt2) {
								String sCommand2 = myTextField2.getText().toString();
								myTextField2.clear();
								if (sCommand2.charAt(0) == 'y') {//Will ask if the user really wants to quit.
									gw.exitConfirmed();
								} else if (sCommand2.charAt(0) == 'n') {
									addComponent(myTextField);
									removeComponent(myTextField2);
									show();
									System.out.println("Exit cancelled! Enter a command: ");
								} else {
									System.out.println("Please enter 'y' or 'n'!");
								}
							}
						}
						);
						break;
					default:
						System.out.println("Error: Command not recognized.");
						System.out.println("Please see the list of commands below and try again!");
						System.out.print("Commands:\n");
					    System.out.print(" a - To Accelerate the Speed of the Ant\n");
					    System.out.print(" b - To Brake (*Reduce the Speed of) the Ant\n");
					    System.out.print(" l - To Change the Heading of the Ant by Five Degrees to the Left (*Turn Left)\n");
					    System.out.print(" r - To Change the Heading of the Ant by Five Degrees to the Right (*Turn Right)\n");
					    System.out.print(" 1 - To Pretend that the Ant has Collided with Flag Number 1\n");
					    System.out.print(" 2 - To Pretend that the Ant has Collided with Flag Number 2\n");
					    System.out.print(" 3 - To Pretend that the Ant has Collided with Flag Number 3\n");
					    System.out.print(" 4 - To Pretend that the Ant has Collided with Flag Number 4\n");
					    System.out.print(" 5 - To Pretend that the Ant has Collided with Flag Number 5\n");
					    System.out.print(" 6 - To Pretend that the Ant has Collided with Flag Number 6\n");
					    System.out.print(" 7 - To Pretend that the Ant has Collided with Flag Number 7\n");
					    System.out.print(" 8 - To Pretend that the Ant has Collided with Flag Number 8\n");
					    System.out.print(" 9 - To Pretend that the Ant has Collided with Flag Number 9\n");
					    System.out.print(" f - To Pretend that the Ant has Collided with a Food Station\n");
					    System.out.print(" g - To Pretend that the Ant has Collided with a Spider\n");
					    System.out.print(" t - To Tell the Game World that the \"Game Clock\" has Ticked\n");
					    System.out.print(" d - To Generate a Display, Describing the Current Game/Ant State Values\n");
					    System.out.print(" m - To Output a Map\n");
					    System.out.print(" x - To Exit\n");
					    System.out.println();
					}//Switch
				}//Action Performed
			}//new ActionListener()			
		);//addActionListener
	}//play
}