package com.mycompany.a1;

/**
 * An interface class that gets implemented by the Ant class. This class is is simply used to define some turn 
 * methods for the ant, which is supposed to be steerable by the player. 
 * 
 * @author Santiago A. Bermudez
 * @version 1 September 2022
 */
public interface ISteerable {
	
/**
 * This method is used to turn the ant five degrees to the left.
 */
	void turnLeft();
/**
 * This method is used to turn the ant five degrees to the right.
 */
	void turnRight();
	
}
