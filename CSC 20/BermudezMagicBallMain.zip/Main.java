/*Author: Santiago A Bermudez
Date: 1-27-20
Description: This is supposed to simulate playing a magic ball. It was supposed to get input its responses into a file and read from it.
*/
import java.util.*;
import java.io.*;

class Main {

  public static void main(String[] args)throws Exception {//Exception
  //helps with printstream.
    System.out.println("\nWelcome to the Magic Ball Program!\n");
   // PrintStream output = new PrintStream(new File("answers.txt"));
/*
    output.print("It is certain.");
    output.print("It is decidedly so.");
    output.print("Without a doubt.");
    output.print("Yes, definitely.");
    output.print("You may rely on it.");
    output.print("As I see it, yes.");
    output.print("Most likely.");
    output.print("Outlook good.");
    output.print("Signs point to yes.");
    output.print("Reply hazy try again.");
    output.print("Ask again later.");
    output.print("Cannot predict now.");
    output.print("Concentrate and ask again.");
    output.print("Don't count on it.");
    output.print("My reply is no.");
    output.print("My sources say no.");
    output.print("Outlook not so good.");
    output.print("Very doubtful.");
    output.print("The stars say yes.");
*/
 String panswer[] = {"It is certain.","It is decidedly so.","Without a doubt.","Yes, definitely.","You may rely on it.","As I see it, yes.","Most likely.","Outlook good.","Signs point to yes.","Reply hazy try again.","Ask again later.","Cannot predict now.","Concentrate and ask again.","Don't count on it.","My reply is no.","My sources say no.","Outlook not so good.","Very doubtful.","The stars say yes."};//Possible //responses from magic 8 ball.
    
      /*String text = readAnswers("answers.txt");
      System.out.println("Possible answers: ");
      System.out.println(text);
      System.out.println();
*/
      char cond = ' ';//Initial condition value.
      while (cond != 'n') {//While loop that runs until user quits.
       // String[] stuff = new String[20];
        Scanner console = new Scanner(System.in);//Scanner used for user input.
        System.out.println("Ask a question to the magic ball:");
        String phrase;
        phrase = console.next();//Stores input.

        Random rand = new Random();//New random object.
        int ran = randr.nextInt(18)+ 1;    

        String phrased = panswer[ran]; //Random response.
        System.out.println ("\nThe answer to your question is: " + phrased);

        //playGame(answer[]);
        System.out.print("\nDo you want to ask another question? [If so, enter 'y' to continue, otherwise, enter 'n' to stop the program]:");
        char option = console.next().charAt(0);//Used to register only one letter quitting.
        console.nextLine();//Clears console, used for capital letter registration.
        cond = process(option, console);//Allows for the processing of user option.
        System.out.println();//Spacing.
      }
  }

  public static char process(char option, Scanner console){//Calls other methods based on user request.
      char y = 'y';//Continues program.
      char n = 'n';//Only letter needed to end program.  
   
      if(option == y){//Allows for user to continue.
        System.out.print("\nValid input: " + (option == y) + "\n");
      }
      if(option == n){//Sends 'n' back 
       System.out.println("\nValid input: " + (option == n) + "\n");
       System.out.print("[ PROGRAM TERMINATED ]");
      }
      if(option != n){//Allows for user to correct themselves.
         while ((option != 'n') && (option != 'y')){//Prevents incorrect input.
            System.out.println("\nValid input: false");
            System.out.print("\nEnter an appropriate response: ");
            option = console.next().charAt(0);//Gives user a second chance.
            if(option == y){//Allows for user to continue.
               System.out.print("\nValid input: " + (option == y) + "\n");
            }
            if(option == n){//Sends 'n' back 
               System.out.println("\nValid input: " + (option == n) + "\n");
               System.out.print("[ PROGRAM TERMINATED ]");
            }
         }
      }
      return option;//Option becomes the condition.
   } 
}
/*
 public static String readAnswers(String file) {
      int num = 0;
      String text = "";
      try{
      Scanner s = new Scanner(new File(file));
        while(s.hasNextLine()){
          num++;
          text = text + s.nextLine() + " ";
        }
        String[] words = new String[num];
        Scanner s2 = new Scanner(new File(file));
        for(int k =0; k < num; k++) {
          words[k] = s2.next();
          System.out.println(words + " ");
      }
      }
      catch(FileNotFoundException e){
        System.out.println("File not found!");
        return null;
      }
      return text;
    }
  
    public static void playGame(){
      System.out.print("\nPlayed game!\n");
      Random rand = new Random();
      int ran = rand.nextInt(20) + 1;  
        String phrase = answer[ran];
      }
    }
  }*/