public class SizeException extends Exception{
	
	public static final long serialVersionUID = 1L;
	
}
