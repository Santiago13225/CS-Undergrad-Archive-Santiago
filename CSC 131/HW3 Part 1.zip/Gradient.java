public class Gradient {

	public static void main(String[] args) {
		
	}

}
