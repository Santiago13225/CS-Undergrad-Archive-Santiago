public class Grade implements Comparable<Grade>{
	private String key;
	private Double value;
	
	public int compareTo(Grade other) {
		return 0;
	}
	
	public Grade(String key) throws IllegalArgumentException{
		
	}
	
	public Grade(String key, Double value) throws IllegalArgumentException{
		
	}
	
	public Grade(String key, double value) throws IllegalArgumentException{
		
	}
	
	public String getKey() {
		return this.key;
	}
	
	public Double getValue() {
		return this.value;
	}
	
	public String toString() {
		return null;
	}
}
