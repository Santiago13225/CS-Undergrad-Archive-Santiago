import java.util.*;

public class DropFilter implements Filter{
	public boolean shouldDropLowest;
	public boolean shouldDropHighest;
	
	public List<Grade> apply(List<Grade> grades)throws SizeException {
		return null;
	}
	
	public DropFilter() {
		
	}
	
	public DropFilter(boolean shouldDropLowest, boolean shouldDropHighest) {
		
	}
}
