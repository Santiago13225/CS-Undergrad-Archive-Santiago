import java.util.*;

public class WeightedTotalStrategy implements GradingStrategy{
	
	public Map<String, Double> weights;
	
	public Grade calculate(String key, List<Grade> grades) throws SizeException {
		return null;
	}
	
	public WeightedTotalStrategy() {
		this.weights = null;
	}
	
	public WeightedTotalStrategy(Map<String, Double> weights) {
		this.weights = weights;
	}
	
}
