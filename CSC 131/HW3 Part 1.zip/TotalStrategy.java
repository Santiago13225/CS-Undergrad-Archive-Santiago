import java.util.List;

public class TotalStrategy implements GradingStrategy {
	
	public TotalStrategy() {
		
	}

	public Grade calculate (String key, List<Grade> grades) throws SizeException {
		return null;
	}
	
}
