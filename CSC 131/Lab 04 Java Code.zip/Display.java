import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Display extends JLabel implements ActionListener {
	
	private String contents;
	public static final String CLEAR = "C";
	public static final String DELETE = "Del";
	
	public Display() {
		//super(" ");
		super(" ", SwingConstants.RIGHT);
		setBorder(BorderFactory.createEtchedBorder());
		contents = "";
		updateDisplay();
	}
	
	public void actionPerformed(ActionEvent ae) {
		String ac;
		
		ac = ae.getActionCommand();
		if(ac.equals(CLEAR)) {
			contents = "";
			setText("Enter your PIN");
		}else if(ac.equals(DELETE)) {
			if(!contents.equals(""))
				contents = contents.substring(0, contents.length()-1);
		}else {
			contents += ac;
		}
		updateDisplay();
	}
	
	private void updateDisplay() {
		if(contents.equals("")) {
			setForeground(Color.GRAY);
			setText("Enter your PIN");
		}else {
			String asterisks = "";
			
			for(int i = 0; i < contents.length(); i++) {
				asterisks += "*";
			}
			setForeground(Color.RED);
			setText(asterisks);
		}
		
	}
}
