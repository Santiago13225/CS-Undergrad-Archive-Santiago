import java.awt.*;
import javax.swing.*;

/**
 * A window containing a PIN entry pad.
 */

public class PINPadWindow extends JFrame {
    /**
     * Default Constructor.
     */

    public PINPadWindow()
    {
        super();
        setupLayout();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setResizable(false);
    }

    /**
     * Setup and layout this PINPadWindow
     */

    private void setupLayout()
    {
        Container contentPane;
        Display display;
        NumberPad numberPad;

        setSize(300, 300);
        setTitle("ATM");

        contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        
        display = new Display();
        contentPane.add(display, BorderLayout.NORTH);
        
        //numberPad = new NumberPad();
        
        numberPad = new NumberPad(display);
        contentPane.add(numberPad, BorderLayout.CENTER);
        // Layout this PINPadWindow
    }
}
