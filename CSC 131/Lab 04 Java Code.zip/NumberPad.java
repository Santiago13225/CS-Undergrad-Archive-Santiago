import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * A numeric keypad
 */
public class NumberPad extends JPanel{
	
	private ActionListener listener;
    /**
     * Default Constructor
     */
	/*
    public NumberPad()
    {
        super();
        setupLayout();
    }
    */
    public NumberPad(ActionListener listener)
    {
        super();
        
        this.listener = listener;
        setupLayout();
    }

    private void addButton(String text) {
    	JButton button;
    	
    	button = new JButton(text);
    	add(button);
    	button.addActionListener(listener);
    }
    
    /**
     * Setup and layout this NumberPad
     */
    private void setupLayout()
    {
        setLayout(new GridLayout(4, 3));

        for(int i = 1; i <= 9; i++) {
        	 addButton(String.format("%1d", i));
        }

        addButton("Del");
        addButton("0");
        addButton("C");
    }

}
