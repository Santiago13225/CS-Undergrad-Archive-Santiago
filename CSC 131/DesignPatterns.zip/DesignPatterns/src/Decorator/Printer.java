package Decorator;

public interface Printer
{
    public abstract void print(String text);    
}
