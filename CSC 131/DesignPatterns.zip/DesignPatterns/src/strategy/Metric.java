package strategy;

public interface Metric {
	public abstract double distance(double[] x, double[] y);

}
