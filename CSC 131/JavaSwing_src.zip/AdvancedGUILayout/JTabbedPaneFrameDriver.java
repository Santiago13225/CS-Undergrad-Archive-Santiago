package AdvancedGUILayout;

/**
 * An example that uses a JTabbedPane
 *
 */
public class JTabbedPaneFrameDriver
{

    /**
     * The entry point of the example
     *
     * @param args   The command line arguments
     */
    public static void main(String[] args)
    {
        JTabbedPaneFrame   f;

        f = new JTabbedPaneFrame();
        f.setSize(400,200);
        f.setVisible(true);

        
    }
}
