package AdvancedGUILayout;

import java.awt.*;
import javax.swing.*;


/**
 * An example that uses buttons and a
 * tool bar
 *
 */
public class DockDriver
{

    /**
     * The entry point of the example
     *
     * @param args   The command line arguments
     */
    public static void main(String[] args)
    {
        DockFrame   f;

        f = new DockFrame();
        f.setSize(400,400);
        f.setVisible(true);

        
    }
}
